# TWRP A/B Retention Script
### osm0sis @ xda-developers
*Keep TWRP installed after an A/B OTA*

### Links
* [GitHub](https://github.com/Magisk-Modules-Repo/TWRP-A-B-Retention-Script)
* [Support](https://forum.xda-developers.com/showthread.php?t=2239421)
* [Donate](https://forum.xda-developers.com/donatetome.php?u=4544860)

### Description
**This is NOT a normal module - it will NOT show up in Magisk Manager's installed modules list.**

Flash this script zip after each OTA has installed, but before you install Magisk to Inactive Slot from Manager

Initial install should be from the Downloads section in Manager, then subsequent flashes can be from the Modules section using the + button and selecting the downloaded zip from internal storage
